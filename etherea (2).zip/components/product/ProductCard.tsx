
import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../../types';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <Link to={`/product/${product.id}`} className="group block">
      <div className="overflow-hidden">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-auto object-cover aspect-[3/4] transition-transform duration-500 ease-in-out group-hover:scale-105"
        />
      </div>
      <div className="mt-4 text-center">
        <h3 className="font-sans text-sm tracking-wide text-text-main">{product.name}</h3>
        <p className="mt-1 font-sans text-sm text-text-main/70">${product.price.toFixed(2)}</p>
      </div>
    </Link>
  );
};

export default ProductCard;
