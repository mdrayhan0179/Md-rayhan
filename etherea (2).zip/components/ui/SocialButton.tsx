import React from 'react';
import Icon from './Icon';

interface SocialButtonProps {
  provider: 'google' | 'facebook';
  onClick: () => void;
}

const providerStyles = {
  google: {
    bg: 'bg-white',
    text: 'text-text-main',
    border: 'border-border-light',
    hoverBg: 'hover:bg-gray-50',
    label: 'Sign in with Google',
  },
  facebook: {
    bg: 'bg-[#1877F2]',
    text: 'text-white',
    border: 'border-[#1877F2]',
    hoverBg: 'hover:bg-[#166eab]',
    label: 'Sign in with Facebook',
  },
};

const SocialButton: React.FC<SocialButtonProps> = ({ provider, onClick }) => {
  const styles = providerStyles[provider];
  
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center justify-center py-3 px-4 border ${styles.border} ${styles.bg} ${styles.text} ${styles.hoverBg} transition-colors duration-300`}
    >
      <Icon name={provider} className="w-5 h-5 mr-3" />
      <span className="text-sm font-medium">{styles.label}</span>
    </button>
  );
};

export default SocialButton;