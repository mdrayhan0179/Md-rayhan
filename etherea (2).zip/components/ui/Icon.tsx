import React from 'react';

interface IconProps extends React.SVGProps<SVGSVGElement> {
  name: 'search' | 'user' | 'cart' | 'wishlist' | 'menu' | 'close' | 'minus' | 'plus' | 'chevron-down' | 'google' | 'facebook';
}

const icons = {
  search: <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />,
  user: <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />,
  cart: <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />,
  wishlist: <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />,
  menu: <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />,
  close: <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />,
  minus: <path strokeLinecap="round" strokeLinejoin="round" d="M18 12H6" />,
  plus: <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m6-6H6" />,
  'chevron-down': <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />,
  google: <g fill="none" strokeWidth="1.5"><path d="M20.94,11.33H20V11h-8v2h4.67c-0.67,2.33-2.75,4-5.17,4c-3.04,0-5.5-2.46-5.5-5.5s2.46-5.5,5.5-5.5c1.39,0,2.67,0.52,3.65,1.35l1.41-1.41C15.9,2.6,13.56,2,11.5,2C6.25,2,2,6.25,2,11.5S6.25,21,11.5,21c5.25,0,9.5-4.25,9.5-9.5C21,11.67,20.94,11.33,20.94,11.33z"/></g>,
  facebook: <path strokeLinecap="round" strokeLinejoin="round" d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z" />,
};

const Icon: React.FC<IconProps> = ({ name, className = "w-6 h-6", ...props }) => {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      className={className} 
      fill="none" 
      viewBox="0 0 24 24" 
      stroke="currentColor" 
      strokeWidth={1.5}
      {...props}
    >
      {icons[name]}
    </svg>
  );
};

export default Icon;