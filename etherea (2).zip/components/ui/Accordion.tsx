
import React, { useState } from 'react';
import Icon from './Icon';

interface AccordionProps {
  title: string;
  children: React.ReactNode;
}

const Accordion: React.FC<AccordionProps> = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-border-light">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center text-left py-6"
        aria-expanded={isOpen}
      >
        <span className="font-sans font-medium tracking-wide text-primary-black">{title}</span>
        <Icon
          name="chevron-down"
          className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>
      <div
        className={`grid transition-all duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
      >
        <div className="overflow-hidden">
          <div className="pb-6 text-sm text-text-main/80 leading-relaxed prose">
            {children}
          </div>
        </div>
      </div>
      <style>{`
        .prose p { margin-bottom: 1em; }
        .prose a { color: #0A0A0A; text-decoration: underline; }
        .prose a:hover { color: #C0B283; }
      `}</style>
    </div>
  );
};

export default Accordion;
