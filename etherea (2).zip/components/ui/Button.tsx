import React from 'react';
import { Link } from 'react-router-dom';

// FIX: Update ButtonProps to be more flexible, supporting props for button, Link, and anchor elements.
interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
  to?: string;
  className?: string;
  as?: 'a';
  [key: string]: any; // Allow other props like href, onClick, type
}

const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', to, className = '', as, ...props }) => {
  const baseStyles = 'inline-block font-sans tracking-widest uppercase text-xs py-4 px-8 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-gold';
  
  const styles = {
    primary: 'bg-primary-black text-primary-white hover:bg-accent-gold hover:text-primary-black',
    secondary: 'bg-transparent text-primary-black border border-primary-black hover:bg-primary-black hover:text-primary-white',
  };

  const combinedClassName = `${baseStyles} ${styles[variant]} ${className}`;

  if (to) {
    return (
      <Link to={to} className={combinedClassName} {...props}>
        {children}
      </Link>
    );
  }

  if (as === 'a') {
    return (
      <a className={combinedClassName} {...props}>
        {children}
      </a>
    );
  }

  return (
    <button className={combinedClassName} {...props}>
      {children}
    </button>
  );
};

export default Button;
