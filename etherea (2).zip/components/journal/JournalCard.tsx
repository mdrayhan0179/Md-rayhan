
import React from 'react';
import { Link } from 'react-router-dom';
import { JournalPost } from '../../types';

interface JournalCardProps {
  post: JournalPost;
}

const JournalCard: React.FC<JournalCardProps> = ({ post }) => {
  return (
    <Link to={`/journal/${post.id}`} className="group block">
      <div className="overflow-hidden">
        <img
          src={post.imageUrl}
          alt={post.title}
          className="w-full h-auto object-cover aspect-video transition-transform duration-500 ease-in-out group-hover:scale-105"
        />
      </div>
      <div className="mt-6">
        <p className="font-sans text-xs uppercase tracking-widest text-text-main/70 mb-2">{post.date}</p>
        <h3 className="font-serif text-2xl text-primary-black group-hover:text-accent-gold transition-colors">{post.title}</h3>
        <p className="mt-3 text-sm leading-relaxed text-text-main/80">{post.excerpt}</p>
        <div className="mt-4 font-sans text-xs uppercase tracking-widest text-primary-black group-hover:text-accent-gold transition-colors">
          Read More &rarr;
        </div>
      </div>
    </Link>
  );
};

export default JournalCard;
