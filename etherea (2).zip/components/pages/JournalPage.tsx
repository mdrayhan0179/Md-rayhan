
import React, { useState, useEffect } from 'react';
import { shopifyService } from '../../services/shopifyService';
import { JournalPost } from '../../types';
import JournalCard from '../journal/JournalCard';
import ScrollReveal from '../common/ScrollReveal';

const JournalPage: React.FC = () => {
  const [posts, setPosts] = useState<JournalPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      setLoading(true);
      try {
        const fetchedPosts = await shopifyService.getJournalPosts();
        setPosts(fetchedPosts);
      } catch (error) {
        console.error("Failed to fetch journal posts:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchPosts();
  }, []);

  return (
    <div className="bg-primary-white">
      {/* Hero */}
      <div className="py-24 text-center border-b border-border-light">
        <ScrollReveal>
          <h1 className="font-serif text-5xl md:text-6xl">The Journal</h1>
          <p className="mt-4 max-w-2xl mx-auto text-text-main/80">
            Stories of craftsmanship, style, and the pursuit of the permanent.
          </p>
        </ScrollReveal>
      </div>

      {/* Posts Grid */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24">
        {loading ? (
          <div className="text-center">Loading stories...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-24">
            {posts.map((post, index) => (
              <ScrollReveal key={post.id} delay={index * 150}>
                <JournalCard post={post} />
              </ScrollReveal>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default JournalPage;
