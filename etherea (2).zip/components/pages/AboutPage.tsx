
import React from 'react';
import ScrollReveal from '../common/ScrollReveal';

const AboutPage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <ScrollReveal>
            <h1 className="font-serif text-4xl md:text-5xl text-center">Founded on quiet confidence.</h1>
          </ScrollReveal>

          <div className="flex flex-col md:flex-row items-start gap-12 md:gap-24 mt-16">
            <div className="md:w-1/2">
              <ScrollReveal delay={200}>
                <img src="https://picsum.photos/id/160/800/1000" alt="ETHEREA Atelier" className="w-full h-auto object-cover"/>
              </ScrollReveal>
            </div>
            <div className="md:w-1/2">
              <ScrollReveal delay={400}>
                <p className="text-base leading-relaxed text-text-main mb-6">
                  ETHEREA was born from a desire to return to the essential. In a world of fleeting trends, we create singular pieces that endure, crafted with uncompromising quality and a minimalist vision.
                </p>
                <p className="text-base leading-relaxed text-text-main mb-6">
                  Our ateliers in Milan pair traditional tailoring with modern forms, finding beauty in precision. Each garment is an invitation to live thoughtfully, draped in quiet luxury.
                </p>
                <p className="font-serif text-lg italic text-text-main">
                  This is not fashion; it is a permanent state of mind.
                </p>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
