
import React from 'react';
import ScrollReveal from '../common/ScrollReveal';

const lookbookImages = [
  { id: 1, src: 'https://picsum.photos/id/211/800/1200', alt: 'Look 1' },
  { id: 2, src: 'https://picsum.photos/id/212/800/1200', alt: 'Look 2' },
  { id: 3, src: 'https://picsum.photos/id/214/800/1200', alt: 'Look 3' },
  { id: 4, src: 'https://picsum.photos/id/215/800/1200', alt: 'Look 4' },
  { id: 5, src: 'https://picsum.photos/id/234/800/1200', alt: 'Look 5' },
  { id: 6, src: 'https://picsum.photos/id/244/800/1200', alt: 'Look 6' },
];

const LookbookPage: React.FC = () => {
  return (
    <div className="bg-primary-white">
      {/* Hero */}
      <div className="relative h-[60vh] bg-cover bg-center" style={{ backgroundImage: "url('https://picsum.photos/id/10/1920/1080')" }}>
        <div className="absolute inset-0 bg-primary-black/30"></div>
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-center text-primary-white">
          <ScrollReveal>
            <h1 className="font-serif text-5xl md:text-7xl">FW'25 Lookbook</h1>
          </ScrollReveal>
          <ScrollReveal delay={200}>
            <p className="max-w-xl mt-4 text-base md:text-lg font-light tracking-wider">
              An exploration of form, texture, and the quiet confidence of the ETHEREA woman.
            </p>
          </ScrollReveal>
        </div>
      </div>
      
      {/* Gallery */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="columns-1 md:columns-2 lg:columns-3 gap-8">
          {lookbookImages.map((image, index) => (
            <ScrollReveal key={image.id} delay={index * 100} className="mb-8 break-inside-avoid">
              <img src={image.src} alt={image.alt} className="w-full h-auto object-cover" />
            </ScrollReveal>
          ))}
        </div>
        <ScrollReveal className="text-center mt-16">
            <p className="font-serif text-xl text-text-main/80">More stories coming soon.</p>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default LookbookPage;
