
import React from 'react';
import ScrollReveal from '../common/ScrollReveal';

const PrivacyPage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center mb-8">Privacy Policy</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mb-16">
              ETHEREA is committed to protecting your privacy. This policy outlines how we collect, use, disclose, and safeguard your information when you visit our website.
            </p>

            <div className="space-y-12 text-text-main/80 leading-relaxed prose max-w-none">
              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">1. Information We Collect</h2>
                <p>We may collect personal information from you in a variety of ways, including when you visit our site, register, place an order, or subscribe to our newsletter. This information may include your name, email address, mailing address, phone number, and credit card information.</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">2. How We Use Your Information</h2>
                <p>The information we collect may be used to personalize your experience, improve our website, process transactions, and send periodic emails regarding your order or other products and services. We implement a variety of security measures to maintain the safety of your personal information.</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">3. Data Security</h2>
                <p>We are committed to ensuring that your information is secure. We have implemented suitable physical, electronic, and managerial procedures to safeguard and secure the information we collect online to prevent unauthorized access or disclosure.</p>
              </section>
              
              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">4. Cookies and Tracking Technologies</h2>
                <p>Our website uses "cookies" to enhance your experience. Cookies are small files that a site or its service provider transfers to your computer's hard drive through your Web browser (if you allow) that enables the site's or service provider's systems to recognize your browser and capture and remember certain information.</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">5. Your Rights and Choices</h2>
                <p>You have the right to access, correct, or delete your personal information. You may also opt-out of receiving marketing communications from us at any time by following the unsubscribe link in our emails or by contacting us directly.</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">6. Changes to This Policy</h2>
                <p>We may update this privacy policy from time to time in order to reflect, for example, changes to our practices or for other operational, legal, or regulatory reasons. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
              </section>
              
               <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">7. Contact Us</h2>
                <p>If you have any questions about this Privacy Policy, please contact us at <a href="mailto:service@etherea.com" className="underline hover:text-accent-gold">service@etherea.com</a>.</p>
              </section>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default PrivacyPage;
