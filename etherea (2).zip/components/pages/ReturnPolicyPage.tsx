
import React from 'react';
import ScrollReveal from '../common/ScrollReveal';

const ReturnPolicyPage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center mb-8">Return Policy</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mb-16">
              We hope you are delighted with your purchase. However, should you need to make a return, we are here to assist. Our policy is designed to be as simple and seamless as possible.
            </p>

            <div className="space-y-12">
              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">Return Window</h2>
                <p className="text-text-main/80 leading-relaxed">
                  We accept returns within 14 days of the delivery date. Any returns requested after this period will not be accepted.
                </p>
              </div>

              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">Conditions for Return</h2>
                <p className="text-text-main/80 leading-relaxed mb-4">
                  To be eligible for a return, your item must meet the following criteria:
                </p>
                <ul className="list-disc list-inside space-y-2 text-text-main/80">
                  <li>Item must be unworn, unwashed, and in its original, pristine condition.</li>
                  <li>All original tags and packaging must be attached and intact.</li>
                  <li>The item must be free from any marks, makeup, or fragrances.</li>
                </ul>
                <p className="text-text-main/80 leading-relaxed mt-4">
                  We reserve the right to refuse returns that do not meet these standards.
                </p>
              </div>

              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">How to Initiate a Return</h2>
                <p className="text-text-main/80 leading-relaxed">
                  To start a return, please visit our online <button className="underline hover:text-accent-gold">Returns Portal</button> (this is a mock link). You will need your order number and email address. Follow the on-screen instructions to select your item and reason for return.
                </p>
              </div>
              
              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">Refunds</h2>
                <p className="text-text-main/80 leading-relaxed">
                  Once your return is received and inspected, we will send you an email to notify you of the approval or rejection of your refund. If approved, your refund will be processed, and a credit will automatically be applied to your original method of payment within 5-7 business days.
                </p>
              </div>

              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">Exchanges</h2>
                <p className="text-text-main/80 leading-relaxed">
                  We do not offer direct exchanges. If you wish to exchange an item, we recommend returning the original item for a full refund and placing a new order for your desired piece.
                </p>
              </div>
            </div>

          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default ReturnPolicyPage;
