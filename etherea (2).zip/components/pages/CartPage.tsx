
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../contexts/CartContext';
import { useUser } from '../../contexts/UserContext';
import Button from '../ui/Button';
import Icon from '../ui/Icon';
import CheckoutProgress from '../checkout/CheckoutProgress';

const CartPage: React.FC = () => {
  const { cartItems, removeFromCart, updateQuantity, totalPrice } = useCart();
  const { isAuthenticated } = useUser();
  const navigate = useNavigate();

  const handleCheckout = () => {
    if (isAuthenticated) {
      navigate('/shipping-address');
    } else {
      navigate('/account', { state: { from: '/shipping-address' } });
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h1 className="font-serif text-4xl">Your Cart is Empty</h1>
        <p className="mt-4 text-text-main/80">Explore our collection to find something you'll love.</p>
        <Button to="/shop" className="mt-8">Continue Shopping</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <CheckoutProgress currentStep="cart" />
      <h1 className="font-serif text-4xl text-center mb-12">Shopping Cart</h1>
      <div className="flex flex-col lg:flex-row gap-12">
        
        {/* Item List */}
        <div className="lg:w-2/3">
          <div className="border-b border-border-light pb-4 hidden md:grid grid-cols-6 gap-4 font-sans uppercase text-xs tracking-widest text-text-main/70">
            <h3 className="col-span-3">Product</h3>
            <h3 className="text-center">Quantity</h3>
            <h3 className="text-right">Total</h3>
            <h3 className="text-right"></h3>
          </div>
          <ul className="divide-y divide-border-light">
            {cartItems.map((item) => (
              <li key={`${item.id}-${item.selectedSize}-${item.selectedColor.name}`} className="py-6 grid grid-cols-1 md:grid-cols-6 gap-4 items-center">
                
                <div className="col-span-1">
                  <img src={item.images[0]} alt={item.name} className="w-24 h-32 object-cover" />
                </div>
                
                <div className="col-span-2">
                  <p className="font-semibold">{item.name}</p>
                  <p className="text-sm text-text-main/70">Size: {item.selectedSize}</p>
                  <p className="text-sm text-text-main/70">Color: {item.selectedColor.name}</p>
                  <p className="text-sm md:hidden mt-2">${item.price.toFixed(2)}</p>
                </div>

                <div className="col-span-1 flex items-center justify-center">
                  <div className="flex items-center border border-border-light">
                    <button onClick={() => updateQuantity(item.id, item.selectedSize, item.selectedColor.name, item.quantity - 1)} className="p-2 disabled:opacity-50" disabled={item.quantity <= 1}><Icon name="minus" className="w-4 h-4"/></button>
                    <span className="px-4 text-sm">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, item.selectedSize, item.selectedColor.name, item.quantity + 1)} className="p-2"><Icon name="plus" className="w-4 h-4"/></button>
                  </div>
                </div>

                <div className="hidden md:block col-span-1 text-right">
                  <p>${(item.price * item.quantity).toFixed(2)}</p>
                </div>

                <div className="col-span-1 flex justify-end">
                  <button onClick={() => removeFromCart(item.id, item.selectedSize, item.selectedColor.name)} className="text-text-main/50 hover:text-red-500 transition-colors">
                    <Icon name="close" className="w-5 h-5" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Order Summary */}
        <div className="lg:w-1/3">
          <div className="border border-border-light p-8 lg:sticky top-24">
            <h2 className="font-serif text-2xl mb-6">Order Summary</h2>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Estimated Shipping</span>
                <span>FREE</span>
              </div>
            </div>
            <div className="border-t border-border-light mt-6 pt-6">
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
            </div>
            <Button onClick={handleCheckout} className="w-full mt-8">Secure Checkout</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;