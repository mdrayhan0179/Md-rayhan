
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { shopifyService } from '../../services/shopifyService';
import { JournalPost } from '../../types';
import ScrollReveal from '../common/ScrollReveal';

const JournalPostPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [post, setPost] = useState<JournalPost | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const fetchedPost = await shopifyService.getJournalPostById(id);
        setPost(fetchedPost || null);
      } catch (error) {
        console.error("Failed to fetch post:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchPost();
  }, [id]);

  if (loading) return <div className="text-center py-24">Loading...</div>;
  if (!post) return <div className="text-center py-24">Journal post not found.</div>;

  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-3xl mx-auto">
            <header className="text-center mb-12">
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl">{post.title}</h1>
              <div className="mt-4 text-sm text-text-main/70 uppercase tracking-widest">
                <span>{post.author}</span> &bull; <span>{post.date}</span>
              </div>
            </header>
            
            <div className="mb-12">
              <img src={post.imageUrl} alt={post.title} className="w-full h-auto object-cover aspect-video" />
            </div>

            <article 
              className="prose max-w-none"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />

            <div className="mt-16 text-center">
                <Link 
                    to="/journal" 
                    className="font-sans text-xs uppercase tracking-widest text-primary-black hover:text-accent-gold transition-colors border-b border-primary-black hover:border-accent-gold pb-1"
                >
                    &larr; Back to The Journal
                </Link>
            </div>
          </div>
        </ScrollReveal>
      </div>
      <style>{`
        .prose {
          font-family: 'Inter', sans-serif;
          color: #333333;
          line-height: 1.7;
        }
        .prose p {
          margin-bottom: 1.25em;
        }
        .prose h1, .prose h2, .prose h3 {
          font-family: 'Playfair Display', serif;
        }
         .prose strong {
          font-weight: 600;
        }
      `}</style>
    </div>
  );
};

export default JournalPostPage;
