import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useUser } from '../../contexts/UserContext';
import Button from '../ui/Button';
import SocialButton from '../ui/SocialButton';
import ScrollReveal from '../common/ScrollReveal';

const AccountPage: React.FC = () => {
  const { isAuthenticated, userEmail, login, logout } = useUser();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) { // Simple validation
      login(email);
      const from = location.state?.from || '/account';
      navigate(from, { replace: true });
    }
  };
  
  const handleSocialLogin = (provider: 'google' | 'facebook') => {
    // Mock social login
    login(`user@${provider}.com`);
    const from = location.state?.from || '/account';
    navigate(from, { replace: true });
  }

  if (isAuthenticated) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <ScrollReveal>
          <h1 className="font-serif text-4xl">My Account</h1>
          <p className="mt-4 text-text-main/80">Welcome back, {userEmail}.</p>
          <div className="mt-8 space-x-4">
            <Button variant="secondary" onClick={() => navigate('/')}>Continue Shopping</Button>
            <Button onClick={() => { logout(); navigate('/'); }}>Logout</Button>
          </div>
        </ScrollReveal>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24">
      <ScrollReveal>
        <div className="max-w-md mx-auto">
          <h1 className="font-serif text-4xl text-center">Sign In</h1>
          {location.state?.from === '/checkout' && (
            <p className="mt-4 text-center text-text-main/80">
              Please sign in to proceed to checkout.
            </p>
          )}
          
          <div className="mt-8 space-y-4">
            <SocialButton provider="google" onClick={() => handleSocialLogin('google')} />
            <SocialButton provider="facebook" onClick={() => handleSocialLogin('facebook')} />
          </div>

          <div className="my-6 flex items-center">
            <div className="flex-grow border-t border-border-light"></div>
            <span className="mx-4 text-xs uppercase text-text-main/70">Or</span>
            <div className="flex-grow border-t border-border-light"></div>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label htmlFor="email" className="sr-only">Email address</label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold"
                placeholder="Email address"
              />
            </div>
            <div>
              <label htmlFor="password" className="sr-only">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold"
                placeholder="Password"
              />
            </div>
            <Button type="submit" className="w-full">Sign In</Button>
          </form>
          <p className="mt-6 text-center text-sm text-text-main/70">
            Don't have an account?{' '}
            <button className="font-medium hover:text-accent-gold">
              Create one
            </button>
          </p>
        </div>
      </ScrollReveal>
    </div>
  );
};

export default AccountPage;