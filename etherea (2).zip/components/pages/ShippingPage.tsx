
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../../contexts/UserContext';
import Button from '../ui/Button';
import { ShippingAddress } from '../../types';
import CheckoutProgress from '../checkout/CheckoutProgress';

const ShippingPage: React.FC = () => {
  const { isAuthenticated, shippingAddress, setShippingAddress } = useUser();
  const navigate = useNavigate();
  const [formData, setFormData] = useState<ShippingAddress>({
    fullName: shippingAddress?.fullName || '',
    addressLine1: shippingAddress?.addressLine1 || '',
    addressLine2: shippingAddress?.addressLine2 || '',
    city: shippingAddress?.city || '',
    state: shippingAddress?.state || '',
    postalCode: shippingAddress?.postalCode || '',
    country: shippingAddress?.country || 'United States',
  });

  if (!isAuthenticated) {
     return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h1 className="font-serif text-4xl">Access Denied</h1>
        <p className="mt-4 text-text-main/80">You must be signed in to provide shipping details.</p>
        <Button onClick={() => navigate('/account', { state: { from: '/shipping-address' } })} className="mt-8">Sign In</Button>
      </div>
    );
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShippingAddress(formData);
    navigate('/checkout');
  };

  return (
    <div className="bg-primary-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <CheckoutProgress currentStep="shipping" />
            <div className="max-w-2xl mx-auto">
                <h1 className="font-serif text-4xl text-center mb-12">Shipping Address</h1>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="fullName" className="block text-xs uppercase tracking-wider mb-1">Full Name</label>
                        <input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleChange} required className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" />
                    </div>
                    <div>
                        <label htmlFor="addressLine1" className="block text-xs uppercase tracking-wider mb-1">Address Line 1</label>
                        <input type="text" name="addressLine1" id="addressLine1" value={formData.addressLine1} onChange={handleChange} required className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" placeholder="Street address, P.O. box, etc." />
                    </div>
                     <div>
                        <label htmlFor="addressLine2" className="block text-xs uppercase tracking-wider mb-1">Address Line 2 (Optional)</label>
                        <input type="text" name="addressLine2" id="addressLine2" value={formData.addressLine2} onChange={handleChange} className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" placeholder="Apartment, suite, unit, building, floor, etc." />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label htmlFor="city" className="block text-xs uppercase tracking-wider mb-1">City</label>
                            <input type="text" name="city" id="city" value={formData.city} onChange={handleChange} required className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" />
                        </div>
                        <div>
                            <label htmlFor="state" className="block text-xs uppercase tracking-wider mb-1">State / Province</label>
                            <input type="text" name="state" id="state" value={formData.state} onChange={handleChange} required className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" />
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                         <div>
                            <label htmlFor="postalCode" className="block text-xs uppercase tracking-wider mb-1">ZIP / Postal Code</label>
                            <input type="text" name="postalCode" id="postalCode" value={formData.postalCode} onChange={handleChange} required className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" />
                        </div>
                         <div>
                            <label htmlFor="country" className="block text-xs uppercase tracking-wider mb-1">Country</label>
                            <select name="country" id="country" value={formData.country} onChange={handleChange} required className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold">
                                <option>United States</option>
                                <option>Canada</option>
                                <option>United Kingdom</option>
                                <option>Australia</option>
                                <option>Italy</option>
                            </select>
                        </div>
                    </div>
                    <div className="pt-6">
                         <Button type="submit" className="w-full">Continue to Payment</Button>
                    </div>
                </form>
            </div>
        </div>
    </div>
  );
};

export default ShippingPage;