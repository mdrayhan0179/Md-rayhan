
import React from 'react';
import ScrollReveal from '../common/ScrollReveal';

const TermsPage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center mb-8">Terms & Conditions</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mb-16">
              Welcome to ETHEREA. By accessing and using our website, you agree to comply with and be bound by the following terms and conditions. Please review them carefully.
            </p>

            <div className="space-y-12 text-text-main/80 leading-relaxed prose max-w-none">
              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">1. Intellectual Property</h2>
                <p>All content on this website, including but not limited to text, graphics, logos, images, and software, is the property of ETHEREA or its content suppliers and is protected by international copyright laws. The compilation of all content on this site is the exclusive property of ETHEREA.</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">2. Use of the Site</h2>
                <p>This site is for your personal, non-commercial use only. You may not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, create derivative works from, transfer, or sell any information, software, products, or services obtained from this site without our prior written permission.</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">3. Product Information & Pricing</h2>
                <p>We make every effort to display our products and their colors as accurately as possible. However, the displayed colors of the products will depend on your monitor and we cannot guarantee that your monitor will accurately portray the actual colors. All prices are subject to change without notice.</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">4. Limitation of Liability</h2>
                <p>ETHEREA shall not be liable for any special or consequential damages that result from the use of, or the inability to use, the materials on this site or the performance of the products, even if ETHEREA has been advised of the possibility of such damages.</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">5. Governing Law</h2>
                <p>Your use of this site shall be governed in all respects by the laws of Italy, without regard to choice of law provisions. You agree that jurisdiction over and venue in any legal proceeding directly or indirectly arising out of or relating to this site shall be in the state or federal courts located in Milan, Italy.</p>
              </section>
              
              <section>
                <h2 className="font-serif text-2xl text-primary-black mb-4">6. Changes to Terms</h2>
                <p>We reserve the right to make changes to our site, policies, and these Terms & Conditions at any time. If any of these conditions shall be deemed invalid, void, or for any reason unenforceable, that condition shall be deemed severable and shall not affect the validity and enforceability of any remaining condition.</p>
              </section>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default TermsPage;
