
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { shopifyService } from '../../services/shopifyService';
import { Product } from '../../types';
import { useCart } from '../../contexts/CartContext';
import Button from '../ui/Button';

const ProductPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [mainImage, setMainImage] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<{name: string, hex: string} | null>(null);
  const { addToCart } = useCart();
  const [showNotification, setShowNotification] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const fetchedProduct = await shopifyService.getProductById(id);
        if (fetchedProduct) {
          setProduct(fetchedProduct);
          setMainImage(fetchedProduct.images[0]);
          setSelectedSize(fetchedProduct.sizes[0]);
          setSelectedColor(fetchedProduct.colors[0]);
        }
      } catch (error) {
        console.error("Failed to fetch product:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = () => {
    if (product && selectedSize && selectedColor) {
      addToCart(product, selectedSize, selectedColor);
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    }
  };

  if (loading) return <div className="text-center py-24">Loading...</div>;
  if (!product) return <div className="text-center py-24">Product not found.</div>;

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex flex-col lg:flex-row gap-12 lg:gap-24">
        {/* Product Gallery */}
        <div className="lg:w-3/5">
          <div className="mb-4">
            <img src={mainImage} alt={product.name} className="w-full h-auto object-cover aspect-[3/4]" />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {product.images.map((img, index) => (
              <img
                key={index}
                src={img}
                alt={`${product.name} thumbnail ${index + 1}`}
                className={`cursor-pointer aspect-square object-cover ${mainImage === img ? 'outline outline-2 outline-offset-2 outline-primary-black' : ''}`}
                onClick={() => setMainImage(img)}
              />
            ))}
          </div>
        </div>

        {/* Product Information */}
        <div className="lg:w-2/5 lg:sticky top-24 self-start">
          <h1 className="font-serif text-3xl md:text-4xl">{product.name}</h1>
          <p className="text-xl mt-4">${product.price.toFixed(2)}</p>

          {/* Color Swatches */}
          <div className="mt-8">
            <p className="text-sm font-medium">Color: <span className="text-text-main/70">{selectedColor?.name}</span></p>
            <div className="flex space-x-2 mt-2">
              {product.colors.map((color) => (
                <button
                  key={color.name}
                  onClick={() => setSelectedColor(color)}
                  style={{ backgroundColor: color.hex }}
                  className={`w-8 h-8 rounded-full border border-border-light ${selectedColor?.name === color.name ? 'ring-2 ring-offset-2 ring-primary-black' : ''}`}
                  aria-label={color.name}
                />
              ))}
            </div>
          </div>

          {/* Size Selector */}
          <div className="mt-8">
            <p className="text-sm font-medium">Size</p>
            <div className="flex flex-wrap gap-2 mt-2">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`py-2 px-4 border text-sm font-sans transition-colors ${selectedSize === size ? 'bg-primary-black text-primary-white border-primary-black' : 'bg-transparent border-border-light hover:border-primary-black'}`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>
          
          <Button onClick={handleAddToCart} className="w-full mt-8">Add to Cart</Button>

          {/* Product Description & Details */}
          <div className="mt-12 space-y-4">
            <div>
              <h3 className="font-sans font-medium tracking-wide">Description</h3>
              <p className="mt-2 text-sm leading-relaxed text-text-main/80">{product.description}</p>
            </div>
            <div>
              <h3 className="font-sans font-medium tracking-wide">Details & Fit</h3>
              <p className="mt-2 text-sm leading-relaxed text-text-main/80">{product.details}</p>
            </div>
            <div>
              <h3 className="font-sans font-medium tracking-wide">Materials & Care</h3>
              <p className="mt-2 text-sm leading-relaxed text-text-main/80">{product.materials}</p>
            </div>
          </div>
        </div>
      </div>
      {showNotification && (
          <div className="fixed bottom-10 right-10 bg-primary-black text-primary-white py-3 px-6 shadow-lg animate-fade-in-out">
            Added to cart!
          </div>
        )}
        <style>{`
          @keyframes fade-in-out {
            0%, 100% { opacity: 0; transform: translateY(20px); }
            10%, 90% { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in-out {
            animation: fade-in-out 3s ease-in-out;
          }
        `}</style>
    </div>
  );
};

export default ProductPage;
