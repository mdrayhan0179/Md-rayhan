
import React, { useState } from 'react';
import ScrollReveal from '../common/ScrollReveal';
import Button from '../ui/Button';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send the data to a server here.
    console.log('Form submitted:', formData);
    setIsSubmitted(true);
  };

  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center">Get in Touch</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mt-4 mb-16">
              We are here to assist you. Please reach out with any inquiries or feedback, and a member of our team will respond as soon as possible.
            </p>

            <div className="grid md:grid-cols-2 gap-16 items-start">
              {/* Contact Info */}
              <div className="space-y-8">
                <div>
                  <h3 className="font-sans uppercase tracking-widest text-sm mb-2">Customer Service</h3>
                  <a href="mailto:service@etherea.com" className="text-text-main hover:text-accent-gold">service@etherea.com</a>
                </div>
                 <div>
                  <h3 className="font-sans uppercase tracking-widest text-sm mb-2">Press Inquiries</h3>
                  <a href="mailto:press@etherea.com" className="text-text-main hover:text-accent-gold">press@etherea.com</a>
                </div>
                 <div>
                  <h3 className="font-sans uppercase tracking-widest text-sm mb-2">Studio Address</h3>
                  <p className="text-text-main">123 Via Della Moda<br/>Milan, 20121, Italy</p>
                </div>
              </div>
              
              {/* Contact Form */}
              <div>
                {isSubmitted ? (
                  <div className="border border-border-light p-8 text-center">
                    <h3 className="font-serif text-2xl">Thank You</h3>
                    <p className="mt-2 text-text-main/80">Your message has been received. We will get back to you shortly.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label htmlFor="name" className="sr-only">Name</label>
                      <input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold"
                        placeholder="Name"
                      />
                    </div>
                     <div>
                      <label htmlFor="email" className="sr-only">Email</label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        autoComplete="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold"
                        placeholder="Email Address"
                      />
                    </div>
                     <div>
                      <label htmlFor="subject" className="sr-only">Subject</label>
                      <input
                        id="subject"
                        name="subject"
                        type="text"
                        required
                        value={formData.subject}
                        onChange={handleChange}
                        className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold"
                        placeholder="Subject"
                      />
                    </div>
                    <div>
                      <label htmlFor="message" className="sr-only">Message</label>
                      <textarea
                        id="message"
                        name="message"
                        rows={5}
                        required
                        value={formData.message}
                        onChange={handleChange}
                        className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold"
                        placeholder="Your Message"
                      />
                    </div>
                    <Button type="submit" className="w-full">Send Message</Button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default ContactPage;