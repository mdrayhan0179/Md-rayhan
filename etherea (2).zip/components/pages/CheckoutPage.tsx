
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../../contexts/UserContext';
import { useCart } from '../../contexts/CartContext';
import Button from '../ui/Button';
import CheckoutProgress from '../checkout/CheckoutProgress';

const CheckoutPage: React.FC = () => {
  const { isAuthenticated, shippingAddress } = useUser();
  const { totalPrice, cartItems } = useCart();
  const navigate = useNavigate();

  if (!isAuthenticated) {
     return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h1 className="font-serif text-4xl">Access Denied</h1>
        <p className="mt-4 text-text-main/80">You must be signed in to view this page.</p>
        <Button onClick={() => navigate('/account', { state: { from: '/checkout' } })} className="mt-8">Sign In</Button>
      </div>
    );
  }

  if (!shippingAddress) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h1 className="font-serif text-4xl">Missing Shipping Address</h1>
        <p className="mt-4 text-text-main/80">Please provide a shipping address before proceeding to payment.</p>
        <Button onClick={() => navigate('/shipping-address')} className="mt-8">Add Shipping Address</Button>
      </div>
    );
  }

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would process the payment with a real gateway
    navigate('/order-success');
  };

  return (
    <div className="bg-primary-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <CheckoutProgress currentStep="payment" />
        <div className="max-w-4xl mx-auto">
          <h1 className="font-serif text-4xl text-center mb-12">Payment</h1>
          <div className="grid lg:grid-cols-2 gap-16">

            {/* Order Summary & Shipping */}
            <div>
              <div className="border border-border-light p-6 mb-8">
                <h2 className="font-serif text-xl mb-4">Shipping To</h2>
                <div className="text-sm text-text-main/80 space-y-1">
                  <p>{shippingAddress.fullName}</p>
                  <p>{shippingAddress.addressLine1}</p>
                  {shippingAddress.addressLine2 && <p>{shippingAddress.addressLine2}</p>}
                  <p>{shippingAddress.city}, {shippingAddress.state} {shippingAddress.postalCode}</p>
                  <p>{shippingAddress.country}</p>
                </div>
                 <Button variant="secondary" className="text-xs mt-4 py-2 px-4" onClick={() => navigate('/shipping-address')}>Change</Button>
              </div>
              <div className="border border-border-light p-6">
                <h2 className="font-serif text-xl mb-4">Order Summary</h2>
                 <div className="space-y-3">
                  {cartItems.map(item => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="text-text-main/80">{item.name} x {item.quantity}</span>
                      <span>${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                 </div>
                 <div className="border-t border-border-light mt-4 pt-4">
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>${totalPrice.toFixed(2)}</span>
                  </div>
                 </div>
              </div>
            </div>

            {/* Payment Form */}
            <div>
              <h2 className="font-serif text-xl mb-4">Payment Details</h2>
              <form onSubmit={handlePayment} className="space-y-4">
                 <div>
                    <label htmlFor="card-number" className="block text-xs uppercase tracking-wider mb-1">Card Number</label>
                    <input type="text" id="card-number" placeholder="•••• •••• •••• ••••" className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" required />
                  </div>
                   <div>
                    <label htmlFor="card-name" className="block text-xs uppercase tracking-wider mb-1">Name on Card</label>
                    <input type="text" id="card-name" placeholder="John M. Doe" className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" required />
                  </div>
                  <div className="flex gap-4">
                    <div className="w-1/2">
                      <label htmlFor="expiry-date" className="block text-xs uppercase tracking-wider mb-1">Expiry (MM/YY)</label>
                      <input type="text" id="expiry-date" placeholder="MM/YY" className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" required />
                    </div>
                    <div className="w-1/2">
                      <label htmlFor="cvc" className="block text-xs uppercase tracking-wider mb-1">CVC</label>
                      <input type="text" id="cvc" placeholder="CVC" className="w-full text-base bg-transparent border border-border-light py-3 px-4 focus:outline-none focus:border-accent-gold" required />
                    </div>
                  </div>
                  <Button type="submit" className="w-full mt-8">Pay ${totalPrice.toFixed(2)}</Button>
              </form>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;