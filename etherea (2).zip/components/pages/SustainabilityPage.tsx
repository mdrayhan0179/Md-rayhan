
import React from 'react';
import ScrollReveal from '../common/ScrollReveal';

const SustainabilityPage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center">In Pursuit of the Permanent</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mt-4 mb-16">
              For us, sustainability is not a trend; it is an extension of our core philosophy. It is the belief that true luxury is timeless, responsible, and crafted with a conscience. We are committed to making choices that honor both people and the planet.
            </p>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={200}>
           <img src="https://picsum.photos/id/15/1200/600" alt="Lush natural landscape" className="w-full h-auto object-cover mb-24"/>
        </ScrollReveal>
        
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            
            <div className="space-y-12">
               <ScrollReveal>
                <div>
                  <h2 className="font-serif text-2xl mb-2">Timeless Design</h2>
                  <p className="text-text-main/80 leading-relaxed">
                    We create pieces that transcend seasons. Our minimalist aesthetic focuses on impeccable tailoring and enduring silhouettes, encouraging a philosophy of "buy less, but better." Each garment is designed to be a permanent fixture in your wardrobe.
                  </p>
                </div>
               </ScrollReveal>
               <ScrollReveal>
                <div>
                  <h2 className="font-serif text-2xl mb-2">Conscious Materials</h2>
                  <p className="text-text-main/80 leading-relaxed">
                    We partner with suppliers who share our commitment to ethical and environmental responsibility. From our Tuscan wool to our Italian leather, we prioritize natural, renewable fibers and materials sourced from transparent supply chains.
                  </p>
                </div>
              </ScrollReveal>
            </div>

            <div>
              <ScrollReveal>
                <img src="https://picsum.photos/id/29/800/1000" alt="Hands working with fabric" className="w-full h-auto object-cover" />
              </ScrollReveal>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-16 items-center mt-24">
             <div>
              <ScrollReveal>
                <img src="https://picsum.photos/id/35/800/1000" alt="Artisan tailoring a garment" className="w-full h-auto object-cover" />
              </ScrollReveal>
            </div>
            <div className="space-y-12">
               <ScrollReveal>
                <div>
                  <h2 className="font-serif text-2xl mb-2">Artisanal Craftsmanship</h2>
                  <p className="text-text-main/80 leading-relaxed">
                    Our garments are made by skilled artisans in small, family-owned ateliers in Europe. This not only ensures unparalleled quality and attention to detail but also supports traditional craftsmanship and local economies.
                  </p>
                </div>
               </ScrollReveal>
               <ScrollReveal>
                <div>
                  <h2 className="font-serif text-2xl mb-2">Mindful Packaging</h2>
                  <p className="text-text-main/80 leading-relaxed">
                    Your ETHEREA order arrives in packaging made from recycled and recyclable materials. We have eliminated unnecessary plastics and are continuously seeking innovative solutions to minimize our environmental footprint.
                  </p>
                </div>
              </ScrollReveal>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default SustainabilityPage;