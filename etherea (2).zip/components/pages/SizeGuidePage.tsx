
import React from 'react';
import ScrollReveal from '../common/ScrollReveal';

const SizeGuidePage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center mb-8">Size Guide</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mb-16">
              Finding your perfect fit is essential for the ETHEREA experience. Our garments are designed to drape beautifully, and this guide will help you select the size that best complements your form. All measurements are in inches and centimeters.
            </p>

            <div className="mb-16">
              <h2 className="font-serif text-3xl text-center mb-8">How to Measure</h2>
              <div className="grid md:grid-cols-3 gap-8 text-center">
                <div>
                  <h3 className="font-sans font-semibold tracking-wide mb-2">Bust</h3>
                  <p className="text-sm text-text-main/80">Measure around the fullest part of your chest, keeping the tape parallel to the floor.</p>
                </div>
                <div>
                  <h3 className="font-sans font-semibold tracking-wide mb-2">Waist</h3>
                  <p className="text-sm text-text-main/80">Measure around your natural waistline, which is the narrowest part of your torso.</p>
                </div>
                <div>
                  <h3 className="font-sans font-semibold tracking-wide mb-2">Hips</h3>
                  <p className="text-sm text-text-main/80">Stand with your feet together and measure around the fullest part of your hips and seat.</p>
                </div>
              </div>
            </div>

            <div>
              <h2 className="font-serif text-3xl text-center mb-8">International Sizing</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="border-b border-border-light">
                    <tr>
                      <th className="p-4 font-sans uppercase text-xs tracking-widest">Size</th>
                      <th className="p-4 font-sans uppercase text-xs tracking-widest">US</th>
                      <th className="p-4 font-sans uppercase text-xs tracking-widest">UK</th>
                      <th className="p-4 font-sans uppercase text-xs tracking-widest">EU</th>
                      <th className="p-4 font-sans uppercase text-xs tracking-widest">Bust</th>
                      <th className="p-4 font-sans uppercase text-xs tracking-widest">Waist</th>
                      <th className="p-4 font-sans uppercase text-xs tracking-widest">Hips</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-border-light">
                      <td className="p-4 font-semibold">XS</td>
                      <td className="p-4">2</td>
                      <td className="p-4">6</td>
                      <td className="p-4">34</td>
                      <td className="p-4">32-33" / 81-84cm</td>
                      <td className="p-4">24-25" / 61-64cm</td>
                      <td className="p-4">34-35" / 86-89cm</td>
                    </tr>
                    <tr className="border-b border-border-light">
                      <td className="p-4 font-semibold">S</td>
                      <td className="p-4">4</td>
                      <td className="p-4">8</td>
                      <td className="p-4">36</td>
                      <td className="p-4">34-35" / 86-89cm</td>
                      <td className="p-4">26-27" / 66-69cm</td>
                      <td className="p-4">36-37" / 91-94cm</td>
                    </tr>
                    <tr className="border-b border-border-light">
                      <td className="p-4 font-semibold">M</td>
                      <td className="p-4">6</td>
                      <td className="p-4">10</td>
                      <td className="p-4">38</td>
                      <td className="p-4">36-37" / 91-94cm</td>
                      <td className="p-4">28-29" / 71-74cm</td>
                      <td className="p-4">38-39" / 97-99cm</td>
                    </tr>
                    <tr className="border-b border-border-light">
                      <td className="p-4 font-semibold">L</td>
                      <td className="p-4">8</td>
                      <td className="p-4">12</td>
                      <td className="p-4">40</td>
                      <td className="p-4">38-39" / 97-99cm</td>
                      <td className="p-4">30-31" / 76-79cm</td>
                      <td className="p-4">40-41" / 102-104cm</td>
                    </tr>
                    <tr>
                      <td className="p-4 font-semibold">XL</td>
                      <td className="p-4">10</td>
                      <td className="p-4">14</td>
                      <td className="p-4">42</td>
                      <td className="p-4">40-41" / 102-104cm</td>
                      <td className="p-4">32-33" / 81-84cm</td>
                      <td className="p-4">42-43" / 107-109cm</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default SizeGuidePage;
