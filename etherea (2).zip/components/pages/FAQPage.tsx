
import React from 'react';
import { Link } from 'react-router-dom';
import ScrollReveal from '../common/ScrollReveal';
import Accordion from '../ui/Accordion';

const faqData = [
  {
    question: "How do I find my size?",
    answer: (
      <p>
        Please refer to our comprehensive <Link to="/size-guide">Size Guide</Link> for detailed measurements and international conversions. For item-specific fit notes, see the 'Details & Fit' information on each product page.
      </p>
    ),
  },
  {
    question: "What is your return policy?",
    answer: (
      <p>
        We accept returns within 14 days of delivery. Items must be in original, unworn condition with all tags attached. For more details, please review our full <Link to="/returns">Return Policy</Link>.
      </p>
    ),
  },
  {
    question: "Do you ship internationally?",
    answer: (
      <p>
        Yes, we ship worldwide. International shipping rates and estimated delivery times are calculated at checkout. Please see our <Link to="/shipping">Shipping Policy</Link> for more information on international duties and taxes.
      </p>
    ),
  },
  {
    question: "How can I track my order?",
    answer: (
      <p>
        Once your order has been dispatched, you will receive a shipping confirmation email containing a tracking number. You can use this number to follow your package's journey.
      </p>
    ),
  },
  {
    question: "How should I care for my garments?",
    answer: (
      <p>
        To preserve the quality of your ETHEREA pieces, we recommend following the specific care instructions on the garment's label. You can also find material and care information in the 'Materials & Care' section on each product page. Generally, we advise professional dry cleaning for most of our tailored items and delicate fabrics.
      </p>
    ),
  },
  {
    question: "Can I cancel or modify my order after it has been placed?",
    answer: (
      <p>
        We process orders quickly to ensure timely delivery. If you need to modify or cancel an order, please contact our customer service team immediately. We will do our best to accommodate your request, but we cannot guarantee changes can be made once an order has been processed.
      </p>
    ),
  },
];

const FAQPage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-3xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center mb-8">Frequently Asked Questions</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mb-16">
              Have a question? We're here to help. Find answers to some of our most common inquiries below.
            </p>

            <div className="space-y-2">
              {faqData.map((item, index) => (
                <Accordion key={index} title={item.question}>
                  {item.answer}
                </Accordion>
              ))}
            </div>

          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default FAQPage;
