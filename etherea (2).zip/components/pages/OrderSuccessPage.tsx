
import React, { useEffect } from 'react';
import Button from '../ui/Button';
import ScrollReveal from '../common/ScrollReveal';
import { useCart } from '../../contexts/CartContext';
import { useUser } from '../../contexts/UserContext';

const OrderSuccessPage: React.FC = () => {
  const { clearCart } = useCart();
  const { setShippingAddress } = useUser();

  useEffect(() => {
    // Clear cart and shipping address on successful order
    clearCart();
    setShippingAddress(null);
  }, [clearCart, setShippingAddress]);

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
      <ScrollReveal>
        <h1 className="font-serif text-4xl">Thank You</h1>
        <p className="mt-4 text-text-main/80 max-w-xl mx-auto">
          Your order has been placed successfully. A confirmation email has been sent to you with the order details.
        </p>
        <Button to="/" className="mt-8">Continue Shopping</Button>
      </ScrollReveal>
    </div>
  );
};

export default OrderSuccessPage;