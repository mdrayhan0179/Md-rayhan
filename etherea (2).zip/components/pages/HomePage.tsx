
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { shopifyService } from '../../services/shopifyService';
import { Product } from '../../types';
import Button from '../ui/Button';
import ProductCard from '../product/ProductCard';
import ScrollReveal from '../common/ScrollReveal';

const HomePage: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [newArrivals, setNewArrivals] = useState<Product[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const allProducts = await shopifyService.getProducts();
        // Simple logic for featured/new arrivals from mock data
        setFeaturedProducts(allProducts.slice(0, 3));
        const arrivals = await shopifyService.getProducts('new-arrivals');
        setNewArrivals(arrivals);
      } catch (error) {
        console.error("Failed to fetch products for homepage:", error);
      }
    };
    fetchProducts();
  }, []);

  return (
    <div className="bg-primary-white">
      {/* Section 1: Hero Banner */}
      <section className="relative h-screen bg-cover bg-center flex items-center justify-center" style={{ backgroundImage: "url('https://picsum.photos/id/1011/1920/1080')" }}>
        <div className="absolute inset-0 bg-primary-black/40"></div>
        <div className="relative z-10 text-center text-primary-white">
          <ScrollReveal>
            <h1 className="font-serif text-5xl md:text-7xl">Where Form Meets Soul.</h1>
          </ScrollReveal>
          <ScrollReveal delay={200}>
            <p className="mt-4 max-w-2xl mx-auto text-lg">
              Discover the FW'25 Collection, a study in material honesty and timeless silhouettes.
            </p>
          </ScrollReveal>
          <ScrollReveal delay={400}>
            <Button to="/shop" variant="secondary" className="mt-8 border-primary-white text-primary-white hover:bg-primary-white hover:text-primary-black">
              Shop The Collection
            </Button>
          </ScrollReveal>
        </div>
      </section>

      {/* Section 2: Featured Collection */}
      <section className="py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <h2 className="font-serif text-4xl text-center">The Edit</h2>
            <p className="mt-2 text-center text-text-main/70">Our curated picks for the season.</p>
          </ScrollReveal>
          <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
            {featuredProducts.map((product, index) => (
              <ScrollReveal key={product.id} delay={index * 150}>
                <ProductCard product={product} />
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
      
      {/* Section 3: Brand Statement */}
      <section className="bg-gray-50 py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center gap-12 md:gap-24">
            <div className="md:w-1/2">
              <ScrollReveal>
                <img src="https://picsum.photos/id/160/800/1000" alt="ETHEREA Craftsmanship" className="w-full h-auto object-cover"/>
              </ScrollReveal>
            </div>
            <div className="md:w-1/2 text-center md:text-left">
              <ScrollReveal>
                <h2 className="font-serif text-4xl">Crafted for the Connoisseur.</h2>
                <p className="mt-4 text-text-main/80 leading-relaxed">
                  ETHEREA was born from a desire to return to the essential. In a world of fleeting trends, we create singular pieces that endure, crafted with uncompromising quality and a minimalist vision.
                </p>
                <Button to="/about" variant="secondary" className="mt-8">Read Our Story</Button>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>

      {/* Section 4: New Arrivals */}
      <section className="py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal>
                <h2 className="font-serif text-4xl text-center">New Arrivals</h2>
            </ScrollReveal>
            <div className="mt-16 relative">
                <div className="flex overflow-x-auto space-x-8 pb-8 scrollbar-hide">
                    {newArrivals.map((product, index) => (
                        <div key={product.id} className="flex-shrink-0 w-80">
                             <ScrollReveal delay={index * 150}>
                                <ProductCard product={product} />
                            </ScrollReveal>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      </section>

      {/* Section 5: Lookbook Teaser */}
       <section className="relative h-[70vh] bg-cover bg-center bg-fixed flex items-center justify-center" style={{ backgroundImage: "url('https://picsum.photos/id/212/1920/1080')" }}>
        <div className="absolute inset-0 bg-primary-black/30"></div>
        <div className="relative z-10 text-center text-primary-white">
          <ScrollReveal>
            <h2 className="font-serif text-5xl">The Lookbook</h2>
            <p className="mt-2 text-lg">FW'25</p>
          </ScrollReveal>
          <ScrollReveal delay={200}>
            <Button to="/lookbook" variant="secondary" className="mt-8 border-primary-white text-primary-white hover:bg-primary-white hover:text-primary-black">
                Explore The Vision
            </Button>
          </ScrollReveal>
        </div>
      </section>

      {/* Section 6: Instagram Gallery */}
      <section className="py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <h2 className="font-serif text-4xl text-center">As Seen On...</h2>
            <p className="mt-2 text-center text-text-main/70">@ETHEREA</p>
          </ScrollReveal>
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[234, 244, 215, 211].map((id, index) => (
              <ScrollReveal key={id} delay={index * 150}>
                <div className="aspect-square overflow-hidden">
                    <img src={`https://picsum.photos/id/${id}/500/500`} alt="Instagram post" className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"/>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
        .bg-fixed {
            background-attachment: fixed;
        }
      `}</style>
    </div>
  );
};

export default HomePage;
