
import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { shopifyService } from '../../services/shopifyService';
import { Product } from '../../types';
import ProductCard from '../product/ProductCard';
import ScrollReveal from '../common/ScrollReveal';

const ShopPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { category } = useParams<{ category?: string }>();
  const location = useLocation();

  const getCategoryTitle = () => {
    if(!category) return "All Products";
    if(category === "new-arrivals") return "New Arrivals";
    return category.charAt(0).toUpperCase() + category.slice(1);
  }

  const pageTitle = getCategoryTitle();

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const fetchedProducts = await shopifyService.getProducts(category);
        setProducts(fetchedProducts);
      } catch (error) {
        console.error("Failed to fetch products:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [category, location.key]);

  return (
    <div className="bg-primary-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Collection Hero */}
        <div className="py-16 text-center border-b border-border-light">
          <h1 className="font-serif text-4xl md:text-5xl">{pageTitle}</h1>
          <p className="mt-4 max-w-2xl mx-auto text-text-main/80">Discover our collection of timeless pieces, crafted with precision and care.</p>
        </div>

        {/* Filters & Sorting (Static for now) */}
        <div className="flex justify-between items-center py-6">
          <button className="font-sans uppercase text-xs tracking-widest">Filter</button>
          <button className="font-sans uppercase text-xs tracking-widest flex items-center">
            Sort By <span className="ml-2">&darr;</span>
          </button>
        </div>

        {/* Product Grid */}
        {loading ? (
          <div className="text-center py-24">Loading products...</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
            {products.map((product, index) => (
              <ScrollReveal key={product.id} delay={index * 100}>
                <ProductCard product={product} />
              </ScrollReveal>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ShopPage;
