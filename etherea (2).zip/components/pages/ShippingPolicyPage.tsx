
import React from 'react';
import { Link } from 'react-router-dom';
import ScrollReveal from '../common/ScrollReveal';

const ShippingPolicyPage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center mb-8">Shipping Policy</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mb-16">
              We are committed to delivering your ETHEREA pieces with the care and expediency they deserve. Below you will find details regarding our shipping process.
            </p>

            <div className="space-y-12">
              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">Processing Time</h2>
                <p className="text-text-main/80 leading-relaxed">
                  All orders are processed within 24 hours of being placed, Monday through Friday, excluding public holidays. Orders placed on weekends or holidays will be processed on the next business day. You will receive a shipment confirmation email once your order has been dispatched.
                </p>
              </div>

              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">Domestic Shipping (USA)</h2>
                <p className="text-text-main/80 leading-relaxed mb-4">
                  We offer the following options for shipping within the United States:
                </p>
                <ul className="list-disc list-inside space-y-2 text-text-main/80">
                  <li><strong>Standard Shipping:</strong> Complimentary on all orders. Estimated delivery within 3-5 business days.</li>
                  <li><strong>Express Shipping:</strong> $25 USD. Estimated delivery within 1-2 business days.</li>
                </ul>
              </div>

              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">International Shipping</h2>
                <p className="text-text-main/80 leading-relaxed">
                  We offer worldwide shipping via our trusted courier partners. Shipping rates and delivery times are calculated at checkout based on your destination. Please be aware that international orders may be subject to customs duties and taxes, which are the responsibility of the recipient. ETHEREA is not responsible for any customs delays.
                </p>
              </div>
              
              <div>
                <h2 className="font-serif text-2xl mb-4 border-b border-border-light pb-2">Order Tracking</h2>
                <p className="text-text-main/80 leading-relaxed">
                  Once your order has been shipped, you will receive an email containing your tracking number. This number will allow you to track your package's journey from our atelier to your doorstep. If you have any questions about the status of your order, please do not hesitate to <Link to="/contact" className="underline hover:text-accent-gold">contact us</Link>.
                </p>
              </div>
            </div>

          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default ShippingPolicyPage;