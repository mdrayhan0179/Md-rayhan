import React from 'react';
import ScrollReveal from '../common/ScrollReveal';
import Button from '../ui/Button';

const jobOpenings = [
  {
    title: 'Digital Marketing Manager',
    location: 'Milan / Remote',
    department: 'Marketing',
  },
  {
    title: 'Atelier Assistant',
    location: 'Milan, Italy',
    department: 'Production',
  },
  {
    title: 'Client Advisor',
    location: 'Remote',
    department: 'Customer Experience',
  },
];

const CareersPage: React.FC = () => {
  return (
    <div className="bg-primary-white py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-center">Join the Pursuit</h1>
            <p className="text-center text-text-main/80 max-w-2xl mx-auto mt-4 mb-16">
              At ETHEREA, we are a collective of artisans, designers, and storytellers dedicated to the idea of permanence. We believe in quiet luxury, uncompromising quality, and a thoughtful approach to fashion. If you share our vision, we invite you to explore a career with us.
            </p>
          </div>
        </ScrollReveal>

        <div className="max-w-5xl mx-auto">
          <ScrollReveal delay={200}>
            <div className="grid md:grid-cols-2 gap-16 items-center mb-24">
              <div>
                <img src="https://picsum.photos/id/1078/800/1000" alt="Collaborative workspace" className="w-full h-auto object-cover" />
              </div>
              <div className="space-y-8">
                <div>
                  <h2 className="font-serif text-2xl mb-2">Dedication to Craft</h2>
                  <p className="text-text-main/80 leading-relaxed">
                    We are deeply committed to the art of making. Our team values precision, patience, and a profound respect for materials and technique.
                  </p>
                </div>
                <div>
                  <h2 className="font-serif text-2xl mb-2">A Collaborative Spirit</h2>
                  <p className="text-text-main/80 leading-relaxed">
                    Our best work is born from collaboration. We foster an environment of open dialogue and mutual respect, where diverse perspectives are celebrated.
                  </p>
                </div>
                 <div>
                  <h2 className="font-serif text-2xl mb-2">A Sustainable Mindset</h2>
                  <p className="text-text-main/80 leading-relaxed">
                    We believe in creating a positive impact. From our supply chain to our studio practices, we are committed to making responsible choices for our planet and our community.
                  </p>
                </div>
              </div>
            </div>
          </ScrollReveal>

          <ScrollReveal>
            <div className="text-center border-t border-border-light pt-16">
              <h2 className="font-serif text-3xl md:text-4xl">Open Positions</h2>
              <p className="text-center text-text-main/80 max-w-2xl mx-auto mt-4 mb-12">
                We are always looking for passionate and talented individuals to join our team.
              </p>
            </div>
          </ScrollReveal>

          <div className="space-y-6">
            {jobOpenings.map((job, index) => (
              <ScrollReveal key={index} delay={index * 100}>
                <div className="border border-border-light p-8 flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div>
                    <h3 className="font-serif text-xl">{job.title}</h3>
                    <p className="text-sm text-text-main/70 mt-1">{job.department} &bull; {job.location}</p>
                  </div>
                  <div className="mt-4 md:mt-0">
                    <a href="mailto:careers@etherea.com?subject=Application:%20Digital%20Marketing%20Manager" className="font-sans uppercase text-xs tracking-widest text-primary-black hover:text-accent-gold border-b border-primary-black pb-1">
                      Apply Now
                    </a>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
          
           <ScrollReveal>
            <div className="text-center border-t border-border-light pt-16 mt-24">
              <h2 className="font-serif text-3xl">Spontaneous Applications</h2>
              <p className="text-center text-text-main/80 max-w-2xl mx-auto mt-4 mb-8">
                Don't see a role that fits? We are always open to connecting with exceptional talent. Send your resume and a cover letter to our team.
              </p>
              <Button as="a" href="mailto:careers@etherea.com?subject=Spontaneous%20Application">
                Get In Touch
              </Button>
            </div>
          </ScrollReveal>

        </div>
      </div>
    </div>
  );
};

export default CareersPage;
