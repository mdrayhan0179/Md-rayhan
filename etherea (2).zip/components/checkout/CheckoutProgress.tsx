
import React from 'react';
import { Link } from 'react-router-dom';

interface CheckoutProgressProps {
  currentStep: 'cart' | 'shipping' | 'payment';
}

const steps = [
  { id: 'cart', name: 'Shopping Cart', path: '/cart' },
  { id: 'shipping', name: 'Shipping', path: '/shipping-address' },
  { id: 'payment', name: 'Payment', path: '/checkout' },
];

const CheckoutProgress: React.FC<CheckoutProgressProps> = ({ currentStep }) => {
  const currentStepIndex = steps.findIndex(step => step.id === currentStep);

  return (
    <nav aria-label="Progress" className="mb-12">
      <ol role="list" className="flex items-center justify-center">
        {steps.map((step, stepIdx) => (
          <li key={step.name} className="relative flex-1">
            {stepIdx < currentStepIndex ? (
              // Completed step
              <>
                <div className="absolute inset-0 top-1/2 -translate-y-1/2 w-full h-0.5 bg-accent-gold" aria-hidden="true" />
                <Link to={step.path} className="relative flex h-8 w-8 items-center justify-center rounded-full bg-accent-gold hover:bg-accent-gold/80">
                  <span className="text-primary-black font-bold">✓</span>
                  <span className="sr-only">{step.name}</span>
                </Link>
              </>
            ) : stepIdx === currentStepIndex ? (
              // Current step
              <>
                <div className="absolute inset-0 top-1/2 -translate-y-1/2 w-full h-0.5 bg-gray-200" aria-hidden="true" />
                 <div className="absolute inset-0 top-1/2 -translate-y-1/2 w-1/2 h-0.5 bg-accent-gold" aria-hidden="true" />
                <div className="relative flex h-8 w-8 items-center justify-center rounded-full border-2 border-accent-gold bg-primary-white" aria-current="step">
                  <span className="h-2.5 w-2.5 rounded-full bg-accent-gold" />
                  <span className="sr-only">{step.name}</span>
                </div>
              </>
            ) : (
              // Upcoming step
              <>
                <div className="absolute inset-0 top-1/2 -translate-y-1/2 w-full h-0.5 bg-gray-200" aria-hidden="true" />
                <div className="relative flex h-8 w-8 items-center justify-center rounded-full border-2 border-gray-300 bg-primary-white">
                   <span className="sr-only">{step.name}</span>
                </div>
              </>
            )}
            <p className="absolute -bottom-6 w-max -translate-x-1/2 left-1/2 text-xs text-center font-medium text-text-main/80">{step.name}</p>
          </li>
        ))}
      </ol>
    </nav>
  );
};

export default CheckoutProgress;