
import React from 'react';

const Preloader: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-primary-white flex items-center justify-center z-50">
      <div className="relative font-serif text-5xl text-primary-black tracking-[0.2em] animate-pulse">
        ETHEREA
        <div className="absolute inset-0 bg-primary-white animate-preload-wipe"></div>
      </div>
      <style>{`
        @keyframes preload-wipe {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-preload-wipe {
          animation: preload-wipe 2s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }
      `}</style>
    </div>
  );
};

export default Preloader;
