
import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../../types';
import { PRODUCTS } from '../../constants';
import Icon from '../ui/Icon';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);
  
  useEffect(() => {
    if (query.trim().length > 1) {
      const lowerCaseQuery = query.toLowerCase();
      const filteredProducts = PRODUCTS.filter(
        (product) =>
          product.name.toLowerCase().includes(lowerCaseQuery) ||
          product.description.toLowerCase().includes(lowerCaseQuery) ||
          product.category.toLowerCase().includes(lowerCaseQuery)
      );
      setResults(filteredProducts);
    } else {
      setResults([]);
    }
  }, [query]);

  const handleClose = () => {
    setQuery('');
    setResults([]);
    onClose();
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div 
      className="fixed inset-0 z-50 bg-primary-white/95 backdrop-blur-sm animate-fade-in"
      onClick={handleClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="search-heading"
    >
      <div 
        className="container mx-auto px-4 sm:px-6 lg:px-8 h-full"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-end pt-8">
            <button onClick={handleClose} className="text-primary-black hover:text-accent-gold" aria-label="Close search">
                <Icon name="close" className="w-8 h-8" />
            </button>
        </div>

        <div className="max-w-3xl mx-auto mt-16">
          <div className="relative">
             <h2 id="search-heading" className="sr-only">Product Search</h2>
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search for products..."
              className="w-full bg-transparent border-b-2 border-primary-black py-4 px-2 font-serif text-3xl text-center text-primary-black placeholder-text-main/50 focus:outline-none focus:border-accent-gold transition-colors"
            />
          </div>

          <div className="mt-12 max-h-[60vh] overflow-y-auto">
            {query.length > 1 && results.length > 0 && (
              <ul className="divide-y divide-border-light">
                {results.map((product) => (
                  <li key={product.id}>
                    <Link
                      to={`/product/${product.id}`}
                      onClick={handleClose}
                      className="flex items-center p-4 -mx-4 group hover:bg-gray-100/50 transition-colors"
                    >
                      <img src={product.images[0]} alt={product.name} className="w-16 h-20 object-cover mr-6 flex-shrink-0" />
                      <div>
                        <h3 className="font-sans text-base tracking-wide text-text-main group-hover:text-accent-gold">{product.name}</h3>
                        <p className="mt-1 font-sans text-sm text-text-main/70">${product.price.toFixed(2)}</p>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
            {query.length > 1 && results.length === 0 && (
              <p className="text-center text-text-main/70">No results found for "{query}".</p>
            )}
          </div>
        </div>
      </div>
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default SearchModal;
