
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary-white border-t border-border-light mt-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 text-center md:text-left">
          
          {/* Customer Care */}
          <div>
            <h3 className="font-sans uppercase tracking-widest text-sm mb-6">Customer Care</h3>
            <ul className="space-y-4">
              <li><Link to="/contact" className="text-sm text-text-main hover:text-accent-gold">Contact</Link></li>
              <li><Link to="/size-guide" className="text-sm text-text-main hover:text-accent-gold">Size Guide</Link></li>
              <li><Link to="/shipping" className="text-sm text-text-main hover:text-accent-gold">Shipping Policy</Link></li>
              <li><Link to="/returns" className="text-sm text-text-main hover:text-accent-gold">Return Policy</Link></li>
              <li><Link to="/faq" className="text-sm text-text-main hover:text-accent-gold">FAQ</Link></li>
            </ul>
          </div>

          {/* Our Company */}
          <div>
            <h3 className="font-sans uppercase tracking-widest text-sm mb-6">Our Company</h3>
            <ul className="space-y-4">
              <li><Link to="/about" className="text-sm text-text-main hover:text-accent-gold">About Us</Link></li>
              <li><Link to="/journal" className="text-sm text-text-main hover:text-accent-gold">Journal</Link></li>
              <li><Link to="/sustainability" className="text-sm text-text-main hover:text-accent-gold">Sustainability</Link></li>
              <li><Link to="/careers" className="text-sm text-text-main hover:text-accent-gold">Careers</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-sans uppercase tracking-widest text-sm mb-6">Legal</h3>
            <ul className="space-y-4">
              <li><Link to="/terms" className="text-sm text-text-main hover:text-accent-gold">Terms & Conditions</Link></li>
              <li><Link to="/privacy" className="text-sm text-text-main hover:text-accent-gold">Privacy Policy</Link></li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div className="md:col-span-1">
             <h3 className="font-sans uppercase tracking-widest text-sm mb-6">Newsletter</h3>
             <p className="text-sm text-text-main mb-4">Subscribe for exclusive previews and stories.</p>
             <form className="flex">
                <input type="email" placeholder="Your Email" className="w-full text-sm bg-transparent border border-border-light py-2 px-3 focus:outline-none focus:border-accent-gold" />
                <button type="submit" className="bg-primary-black text-primary-white px-4 text-sm hover:bg-accent-gold hover:text-primary-black transition-colors">&rarr;</button>
             </form>
          </div>

        </div>
        <div className="mt-16 pt-8 border-t border-border-light text-center text-xs text-text-main/70">
          <p>&copy; {new Date().getFullYear()} ETHEREA. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
