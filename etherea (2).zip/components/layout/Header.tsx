
import React, { useState, useEffect } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useCart } from '../../contexts/CartContext';
import Icon from '../ui/Icon';
import SearchModal from './SearchModal';

const navLinks = [
  { name: 'Shop', path: '/shop' },
  { name: 'Lookbook', path: '/lookbook' },
  { name: 'About', path: '/about' },
  { name: 'Contact', path: '/contact' },
];

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { cartCount } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const activeLinkStyle = {
    boxShadow: '0 1px 0 0 currentColor',
  };

  return (
    <>
      <header className={`sticky top-0 z-40 transition-all duration-300 ${isScrolled ? 'bg-primary-white/80 backdrop-blur-lg shadow-sm' : 'bg-primary-white'}`}>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20 md:h-24">
            
            {/* Mobile Menu Toggle */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(true)} className="text-primary-black">
                <Icon name="menu" className="w-6 h-6"/>
              </button>
            </div>

            {/* Logo */}
            <div className="absolute left-1/2 -translate-x-1/2 md:relative md:left-0 md:translate-x-0">
              <Link to="/" className="font-serif text-3xl tracking-[0.2em] text-primary-black">
                ETHEREA
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex md:items-center md:space-x-10">
              {navLinks.map((link) => (
                <NavLink
                  key={link.name}
                  to={link.path}
                  className="font-sans uppercase text-xs tracking-widest text-primary-black transition-colors hover:text-accent-gold"
                  style={({ isActive }) => (isActive ? activeLinkStyle : undefined)}
                >
                  {link.name}
                </NavLink>
              ))}
            </nav>

            {/* User Icons */}
            <div className="flex items-center space-x-4">
              <button onClick={() => setIsSearchOpen(true)} className="hidden md:block text-primary-black hover:text-accent-gold">
                <Icon name="search" />
              </button>
              <Link to="/account" className="hidden md:block text-primary-black hover:text-accent-gold">
                <Icon name="user" />
              </Link>
              <Link to="/cart" className="relative text-primary-black hover:text-accent-gold">
                <Icon name="cart" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-2 flex items-center justify-center w-4 h-4 text-xs font-bold text-primary-white bg-accent-gold rounded-full">
                    {cartCount}
                  </span>
                )}
              </Link>
            </div>

          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 z-50 bg-primary-white transform ${isMenuOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out md:hidden`}>
        <div className="flex justify-end p-4">
          <button onClick={() => setIsMenuOpen(false)}>
            <Icon name="close" className="w-8 h-8" />
          </button>
        </div>
        <nav className="flex flex-col items-center justify-center h-full -mt-16 space-y-8">
          {navLinks.map((link) => (
            <NavLink
              key={link.name}
              to={link.path}
              onClick={() => setIsMenuOpen(false)}
              className="font-serif text-3xl text-primary-black"
            >
              {link.name}
            </NavLink>
          ))}
           <button onClick={() => { setIsMenuOpen(false); setIsSearchOpen(true); }} className="font-serif text-3xl text-primary-black">
                Search
            </button>
        </nav>
      </div>

      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </>
  );
};

export default Header;
