
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { CartProvider } from './contexts/CartContext';
import { UserProvider } from './contexts/UserContext';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import HomePage from './components/pages/HomePage';
import ShopPage from './components/pages/ShopPage';
import ProductPage from './components/pages/ProductPage';
import CartPage from './components/pages/CartPage';
import Preloader from './components/layout/Preloader';
import AboutPage from './components/pages/AboutPage';
import LookbookPage from './components/pages/LookbookPage';
import AccountPage from './components/pages/AccountPage';
import CheckoutPage from './components/pages/CheckoutPage';
import OrderSuccessPage from './components/pages/OrderSuccessPage';
import SizeGuidePage from './components/pages/SizeGuidePage';
import ShippingPolicyPage from './components/pages/ShippingPolicyPage';
import ReturnPolicyPage from './components/pages/ReturnPolicyPage';
import FAQPage from './components/pages/FAQPage';
import ContactPage from './components/pages/ContactPage';
import JournalPage from './components/pages/JournalPage';
import JournalPostPage from './components/pages/JournalPostPage';
import SustainabilityPage from './components/pages/SustainabilityPage';
import CareersPage from './components/pages/CareersPage';
import TermsPage from './components/pages/TermsPage';
import PrivacyPage from './components/pages/PrivacyPage';
import ShippingPage from './components/pages/ShippingPage';

const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
};

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2000); // Simulate loading time
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return <Preloader />;
  }

  return (
    <UserProvider>
      <CartProvider>
        <HashRouter>
          <ScrollToTop />
          <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/shop" element={<ShopPage />} />
                <Route path="/shop/:category" element={<ShopPage />} />
                <Route path="/product/:id" element={<ProductPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/lookbook" element={<LookbookPage />} />
                <Route path="/account" element={<AccountPage />} />
                <Route path="/shipping-address" element={<ShippingPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/order-success" element={<OrderSuccessPage />} />
                <Route path="/size-guide" element={<SizeGuidePage />} />
                <Route path="/shipping" element={<ShippingPolicyPage />} />
                <Route path="/returns" element={<ReturnPolicyPage />} />
                <Route path="/faq" element={<FAQPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/journal" element={<JournalPage />} />
                <Route path="/journal/:id" element={<JournalPostPage />} />
                <Route path="/sustainability" element={<SustainabilityPage />} />
                <Route path="/careers" element={<CareersPage />} />
                <Route path="/terms" element={<TermsPage />} />
                <Route path="/privacy" element={<PrivacyPage />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </HashRouter>
      </CartProvider>
    </UserProvider>
  );
};

export default App;
