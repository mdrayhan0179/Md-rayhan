
export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  description: string;
  details: string;
  materials: string;
  category: 'Coats' | 'Knitwear' | 'Accessories' | 'New Arrivals';
  images: string[];
  sizes: string[];
  colors: { name: string; hex: string }[];
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize: string;
  selectedColor: { name: string; hex: string };
}

export interface JournalPost {
  id: string;
  title: string;
  excerpt: string;
  imageUrl: string;
  author: string;
  date: string;
  content: string;
}

export interface ShippingAddress {
  fullName: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
}