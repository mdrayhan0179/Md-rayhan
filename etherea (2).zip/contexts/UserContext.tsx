
import React, { createContext, useContext, useState, ReactNode, useMemo } from 'react';
import { ShippingAddress } from '../types';

interface UserContextType {
  isAuthenticated: boolean;
  userEmail: string | null;
  shippingAddress: ShippingAddress | null;
  login: (email: string) => void;
  logout: () => void;
  setShippingAddress: (address: ShippingAddress | null) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress | null>(null);


  const login = (email: string) => {
    setIsAuthenticated(true);
    setUserEmail(email);
    // In a real app, you'd handle tokens/sessions here
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUserEmail(null);
    setShippingAddress(null);
  };

  const value = useMemo(() => ({
    isAuthenticated,
    userEmail,
    shippingAddress,
    login,
    logout,
    setShippingAddress,
  }), [isAuthenticated, userEmail, shippingAddress]);

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};