
import { PRODUCTS, JOURNAL_POSTS } from '../constants';
import { Product, JournalPost } from '../types';

export const shopifyService = {
  getProducts: async (category?: string): Promise<Product[]> => {
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay
    if (category) {
        const categoryTitle = category.charAt(0).toUpperCase() + category.slice(1);
        if (categoryTitle === 'New-arrivals') {
             return PRODUCTS.filter(p => p.category === 'New Arrivals');
        }
        return PRODUCTS.filter(p => p.category === categoryTitle);
    }
    return PRODUCTS;
  },
  
  getProductById: async (id: string): Promise<Product | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return PRODUCTS.find(product => product.id === id);
  },

  getJournalPosts: async (): Promise<JournalPost[]> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return JOURNAL_POSTS;
  },

  getJournalPostById: async (id: string): Promise<JournalPost | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return JOURNAL_POSTS.find(post => post.id === id);
  },
};
